#import <Foundation/Foundation.h>
#import "IndyTypes.h"

@interface IndyUtils : NSObject

+ (void)setRuntimeConfig:(NSString *)config;

@end
